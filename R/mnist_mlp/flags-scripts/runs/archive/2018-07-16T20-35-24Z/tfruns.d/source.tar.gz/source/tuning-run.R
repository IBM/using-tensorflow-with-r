setwd(here::here("mnist_mlp/flags/"))

FLAGS <- flags(
  flag_integer("dense_units1", 128),
  flag_numeric("dropout1", 0.4),
  # flag_integer("dense_units2", 128),
  # flag_numeric("dropout2", 0.3),
  # flag_integer("epochs", 30)
)



runs <- tfruns::tuning_run("mnist_mlp_FLAGS_TUNING.R", flags = list(
  dense_units1 = c(256),
  dropout1 = c(0.2, 0.3)
))  
  # dense_units2 = c(128, 256),
  # dropout2 = c(0.2, 0.3),
  # epochs = c(20, 30)


runs[order(runs$eval_acc, decreasing = TRUE), ]
runs
