setwd(here::here("mnist_mlp/flags/"))

FLAGS <- flags(
  flag_integer("dense_units1", 256),
  flag_integer("epochs", 20)
)




runs <- tfruns::tuning_run("mnist_mlp_FLAGS_TUNING.R", flags = list(
  dense_units1 = c(256, 128),
  epochs = c(20, 30)
))  
  # dense_units2 = c(128, 256),
  # dropout2 = c(0.2, 0.3),
  # epochs = c(20, 30)

ls_runs()


runs[order(runs$eval_acc, decreasing = TRUE), ]
ls_runs()
runs
